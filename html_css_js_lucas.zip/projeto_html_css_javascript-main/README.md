# Disciplina de Construção de Página Web - 2024

Projeto base para a disciplina de CPW. Conteúdos:

topico 1: HTML: introdução, estrutura de documento HTML e principais tags e atributos.

topico 2: formulários e estilização com CSS

topico 3: banners e wireframe. Draw IO  e Adobe Express

topico 4: Javascript: variáveis, conversões, manipulação de vetores e elementos HTML

topico 4.1 : Javascript: manipulação de vetores e elementos HTML

topico 5: HTML 5
